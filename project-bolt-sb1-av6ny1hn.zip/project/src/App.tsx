import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import DetectionPage from './pages/DetectionPage';
import { AppProvider } from './contexts/AppContext';

function App() {
  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <Header />
        <main className="flex-1">
          <DetectionPage />
        </main>
        <Footer />
      </div>
    </AppProvider>
  );
}

export default App;