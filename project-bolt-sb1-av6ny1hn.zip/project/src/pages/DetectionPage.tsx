import React, { useState } from 'react';
import FileUploader from '../components/FileUploader';
import DetectionProgress from '../components/DetectionProgress';
import ResultsDisplay from '../components/ResultsDisplay';
import HistoryPanel from '../components/HistoryPanel';
import InfoSection from '../components/InfoSection';
import { FileUpload, DetectionResult, HistoryItem } from '../types';
import { useAppContext } from '../contexts/AppContext';

const DetectionPage: React.FC = () => {
  const [currentUpload, setCurrentUpload] = useState<FileUpload | null>(null);
  const { addToHistory } = useAppContext();

  const handleFileSelect = (upload: FileUpload) => {
    setCurrentUpload(upload);
  };

  const handleDetectionComplete = (result: DetectionResult) => {
    if (currentUpload) {
      setCurrentUpload({
        ...currentUpload,
        status: 'complete',
        result
      });
    }
  };

  const handleCancelDetection = () => {
    setCurrentUpload(null);
  };

  const handleDismissResult = () => {
    setCurrentUpload(null);
  };

  const handleSaveToHistory = () => {
    if (currentUpload && currentUpload.result) {
      const historyItem: HistoryItem = {
        id: currentUpload.id,
        preview: currentUpload.preview,
        status: currentUpload.status,
        progress: currentUpload.progress,
        result: currentUpload.result,
        timestamp: currentUpload.timestamp,
        fileName: currentUpload.file.name,
        fileSize: currentUpload.file.size,
        fileType: currentUpload.file.type
      };
      
      addToHistory(historyItem);
      setCurrentUpload(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
              Detect Deepfakes with AI
            </h2>
            
            {!currentUpload && (
              <FileUploader onFileSelect={handleFileSelect} />
            )}
            
            {currentUpload && currentUpload.status !== 'complete' && (
              <DetectionProgress 
                upload={currentUpload} 
                onComplete={handleDetectionComplete}
                onCancel={handleCancelDetection}
              />
            )}
            
            {currentUpload && currentUpload.status === 'complete' && currentUpload.result && (
              <ResultsDisplay 
                upload={currentUpload}
                onDismiss={handleDismissResult}
                onSaveToHistory={handleSaveToHistory}
              />
            )}
          </div>
          
          <InfoSection />
        </div>
        
        <div className="lg:col-span-1">
          <HistoryPanel />
        </div>
      </div>
    </div>
  );
};

export default DetectionPage;