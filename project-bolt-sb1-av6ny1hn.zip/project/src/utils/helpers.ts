/**
 * Formats a file size in bytes to a human-readable string
 */
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Generates a unique ID
 */
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

/**
 * Creates a file preview URL
 */
export const createFilePreview = (file: File): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve(reader.result as string);
    };
    reader.readAsDataURL(file);
  });
};

/**
 * Simulates a deepfake detection API call (to be replaced with actual API)
 */
export const simulateDetection = async (file: File): Promise<any> => {
  // Simulate API processing time (1-3 seconds)
  const processingTime = 1000 + Math.random() * 2000;
  
  return new Promise((resolve) => {
    setTimeout(() => {
      // Generate random result for demo purposes
      const isDeepfake = Math.random() > 0.5;
      const confidence = isDeepfake 
        ? 0.7 + Math.random() * 0.3 
        : 0.1 + Math.random() * 0.3;
      
      // For images, sometimes generate detection areas
      let areas = undefined;
      if (file.type.startsWith('image/') && isDeepfake && Math.random() > 0.3) {
        // Create 1-3 detection areas
        const numAreas = Math.floor(Math.random() * 3) + 1;
        areas = Array(numAreas).fill(0).map(() => ({
          x: Math.random() * 0.8,
          y: Math.random() * 0.8,
          width: 0.1 + Math.random() * 0.2,
          height: 0.1 + Math.random() * 0.2,
          score: 0.6 + Math.random() * 0.4
        }));
      }
      
      resolve({
        isDeepfake,
        confidence,
        areas,
        analysisTime: processingTime / 1000,
        message: isDeepfake 
          ? 'This content appears to be artificially generated or manipulated.' 
          : 'No evidence of manipulation was detected in this content.'
      });
    }, processingTime);
  });
};