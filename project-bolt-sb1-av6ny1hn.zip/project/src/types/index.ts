export interface FileUpload {
  id: string;
  file: File;
  preview: string;
  status: 'idle' | 'uploading' | 'processing' | 'complete' | 'error';
  progress: number;
  result?: DetectionResult;
  timestamp: number;
}

export interface DetectionResult {
  isDeepfake: boolean;
  confidence: number;
  areas?: {
    x: number;
    y: number;
    width: number;
    height: number;
    score: number;
  }[];
  analysisTime: number;
  message: string;
}

export interface HistoryItem extends Omit<FileUpload, 'file'> {
  fileName: string;
  fileSize: number;
  fileType: string;
}