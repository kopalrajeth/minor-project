import React from 'react';
import { FileUpload } from '../types';
import { CheckCircle, XCircle, Info, AlertTriangle } from 'lucide-react';
import { formatFileSize } from '../utils/helpers';

interface ResultsDisplayProps {
  upload: FileUpload;
  onDismiss: () => void;
  onSaveToHistory: () => void;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ 
  upload, 
  onDismiss,
  onSaveToHistory 
}) => {
  const { result, file, preview } = upload;
  
  if (!result) return null;
  
  const { isDeepfake, confidence, message, analysisTime, areas } = result;
  
  // Format confidence as percentage
  const confidencePercentage = Math.round(confidence * 100);
  
  // Determine result status classes
  const getStatusClasses = () => {
    if (isDeepfake) {
      return {
        bgColor: 'bg-red-50 dark:bg-red-900/20',
        borderColor: 'border-red-200 dark:border-red-800',
        textColor: 'text-red-700 dark:text-red-300',
        icon: <XCircle className="text-red-500" size={24} />
      };
    }
    return {
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      borderColor: 'border-green-200 dark:border-green-800',
      textColor: 'text-green-700 dark:text-green-300',
      icon: <CheckCircle className="text-green-500" size={24} />
    };
  };
  
  const statusClasses = getStatusClasses();
  
  return (
    <div className="w-full border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden 
      bg-white dark:bg-gray-800 shadow-md transition-all duration-300">
      
      {/* Result header */}
      <div className={`p-4 ${statusClasses.bgColor} border-b ${statusClasses.borderColor} flex items-center justify-between`}>
        <div className="flex items-center space-x-3">
          {statusClasses.icon}
          <div>
            <h3 className={`font-bold ${statusClasses.textColor}`}>
              {isDeepfake ? 'Deepfake Detected' : 'Authentic Content'}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {confidencePercentage}% confidence • {analysisTime.toFixed(1)}s analysis time
            </p>
          </div>
        </div>
        
        <button 
          onClick={onSaveToHistory}
          className="px-3 py-1 text-xs bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
        >
          Save Result
        </button>
      </div>
      
      {/* Content preview */}
      <div className="relative">
        <div className="aspect-video bg-gray-100 dark:bg-gray-900 relative overflow-hidden">
          {file.type.startsWith('image/') ? (
            <img 
              src={preview} 
              alt="Analyzed content" 
              className="w-full h-full object-contain"
            />
          ) : (
            <video 
              src={preview} 
              controls 
              className="w-full h-full object-contain"
            />
          )}
          
          {/* Overlay detection areas if exists and file is an image */}
          {file.type.startsWith('image/') && areas && areas.length > 0 && (
            <div className="absolute inset-0">
              {areas.map((area, index) => (
                <div 
                  key={index}
                  className="absolute border-2 border-red-500 bg-red-500/20 animate-pulse"
                  style={{
                    left: `${area.x * 100}%`,
                    top: `${area.y * 100}%`,
                    width: `${area.width * 100}%`,
                    height: `${area.height * 100}%`
                  }}
                >
                  <div className="absolute -top-6 -left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
                    {Math.round(area.score * 100)}%
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Analysis details */}
      <div className="p-4">
        <div className="flex flex-col space-y-4">
          <div className="bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg">
            <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-1">Analysis Result</h4>
            <p className="text-sm text-gray-700 dark:text-gray-300">
              {message}
            </p>
            
            {isDeepfake && (
              <div className="mt-2 flex items-start space-x-2 text-amber-600 dark:text-amber-400">
                <AlertTriangle size={16} className="mt-0.5 flex-shrink-0" />
                <p className="text-xs">
                  This content appears to be AI-generated or manipulated. Exercise caution before sharing.
                </p>
              </div>
            )}
          </div>
          
          {/* File metadata */}
          <div className="text-sm text-gray-500 dark:text-gray-400">
            <div className="flex flex-wrap gap-x-4 gap-y-1">
              <div><span className="font-medium">Name:</span> {file.name}</div>
              <div><span className="font-medium">Size:</span> {formatFileSize(file.size)}</div>
              <div><span className="font-medium">Type:</span> {file.type}</div>
            </div>
          </div>
          
          {/* Help text */}
          <div className="text-xs flex items-center space-x-2 text-gray-500 dark:text-gray-400 border-t pt-3 dark:border-gray-700">
            <Info size={14} />
            <p>Deepfake detection technology is not 100% accurate. Always verify information from multiple sources.</p>
          </div>
        </div>
      </div>
      
      {/* Actions */}
      <div className="px-4 py-3 bg-gray-50 dark:bg-gray-900/30 border-t dark:border-gray-700 flex justify-end">
        <button 
          onClick={onDismiss}
          className="px-4 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 
          text-gray-800 dark:text-gray-200 rounded transition-colors"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
};

export default ResultsDisplay;