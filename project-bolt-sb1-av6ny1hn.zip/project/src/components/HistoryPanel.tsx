import React from 'react';
import { Clock, Trash2, AlertCircle, CheckCircle } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { formatFileSize } from '../utils/helpers';

const HistoryPanel: React.FC = () => {
  const { history, clearHistory } = useAppContext();

  if (history.length === 0) {
    return (
      <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <Clock className="text-gray-400 dark:text-gray-500 mb-3" size={48} />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No history yet</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md">
            When you analyze content, your recent scans will appear here for quick reference.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
      <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
        <h3 className="font-medium text-gray-900 dark:text-gray-100">Recent Analyses</h3>
        <button
          onClick={clearHistory}
          className="text-xs text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 
            flex items-center gap-1 px-2 py-1 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20"
        >
          <Trash2 size={14} />
          Clear History
        </button>
      </div>

      <div className="divide-y divide-gray-200 dark:divide-gray-700 max-h-[400px] overflow-y-auto">
        {history.map((item) => (
          <div key={item.id} className="p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded overflow-hidden flex-shrink-0">
                <img
                  src={item.preview}
                  alt={item.fileName}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  {item.result?.isDeepfake ? (
                    <span className="flex items-center text-xs px-2 py-0.5 rounded bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300">
                      <AlertCircle size={12} className="mr-1" />
                      Deepfake
                    </span>
                  ) : (
                    <span className="flex items-center text-xs px-2 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">
                      <CheckCircle size={12} className="mr-1" />
                      Authentic
                    </span>
                  )}
                  
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {Math.round((item.result?.confidence || 0) * 100)}% confidence
                  </span>
                </div>
                
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate mt-1">
                  {item.fileName}
                </h4>
                
                <div className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-2">
                  <span>{formatFileSize(item.fileSize)}</span>
                  <span>•</span>
                  <span>{new Date(item.timestamp).toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoryPanel;