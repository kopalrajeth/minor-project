import React from 'react';
import { ShieldAlert, Eye, Brain, AlertTriangle, ArrowRight } from 'lucide-react';

const InfoSection: React.FC = () => {
  return (
    <div className="space-y-8">
      <section className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 
        p-6 rounded-xl shadow-sm border border-blue-100 dark:border-blue-800/50">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-3 flex items-center">
          <ShieldAlert className="mr-2 text-blue-500" size={24} />
          About Deepfake Detection
        </h2>
        
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Deepfakes are synthetic media where a person's likeness is replaced with someone else's using artificial intelligence. 
          Our detection system analyzes visual inconsistencies, unnatural movements, and digital artifacts that are typically 
          present in manipulated content.
        </p>
        
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="text-blue-500 mb-2">
              <Eye size={20} />
            </div>
            <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">Visual Analysis</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Detects inconsistencies in facial features, lighting, and shadows that are often present in deepfakes.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="text-purple-500 mb-2">
              <Brain size={20} />
            </div>
            <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">AI Detection</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Our algorithms identify patterns and artifacts typical of AI-generated content that are invisible to the human eye.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="text-amber-500 mb-2">
              <AlertTriangle size={20} />
            </div>
            <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">Limitations</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              While highly accurate, no detection system is perfect. Always verify information from multiple trusted sources.
            </p>
          </div>
        </div>
      </section>
      
      <section className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
          How to Spot Deepfakes
        </h2>
        
        <ul className="space-y-3">
          {[
            "Unnatural eye movements or blinking patterns",
            "Inconsistent lighting or shadows across the face",
            "Blurry or changing facial features during movement",
            "Unnatural skin tone or texture",
            "Audio that doesn't perfectly sync with lip movements",
            "Strange artifacts around the face, especially when moving"
          ].map((tip, index) => (
            <li key={index} className="flex items-start">
              <ArrowRight className="text-blue-500 mr-2 mt-1 flex-shrink-0" size={16} />
              <span className="text-gray-700 dark:text-gray-300">{tip}</span>
            </li>
          ))}
        </ul>
        
        <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            As deepfake technology evolves, detection becomes more challenging. Our tool uses advanced 
            artificial intelligence to stay ahead of these developments, but critical thinking and 
            media literacy remain essential skills in the digital age.
          </p>
        </div>
      </section>
    </div>
  );
};

export default InfoSection;