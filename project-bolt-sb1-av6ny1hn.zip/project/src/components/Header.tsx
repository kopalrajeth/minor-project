import React from 'react';
import { Shield, Moon, Sun } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';

const Header: React.FC = () => {
  const { isDarkMode, toggleDarkMode } = useAppContext();

  return (
    <header className="sticky top-0 z-10 backdrop-blur-md bg-white/90 dark:bg-gray-900/90 
      border-b border-gray-200 dark:border-gray-800 transition-colors duration-200">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="text-blue-600 dark:text-blue-400" size={28} />
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">DeepDetect</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">AI Deepfake Detection Tool</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 
              text-gray-600 dark:text-gray-300 transition-colors"
            aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;