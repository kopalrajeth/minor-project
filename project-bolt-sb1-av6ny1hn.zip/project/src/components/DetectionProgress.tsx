import React, { useEffect, useState } from 'react';
import { X, AlertCircle, Clock } from 'lucide-react';
import { FileUpload, DetectionResult } from '../types';
import { simulateDetection } from '../utils/helpers';

interface DetectionProgressProps {
  upload: FileUpload;
  onComplete: (result: DetectionResult) => void;
  onCancel: () => void;
}

const DetectionProgress: React.FC<DetectionProgressProps> = ({ 
  upload, 
  onComplete, 
  onCancel 
}) => {
  const [status, setStatus] = useState<FileUpload['status']>(upload.status);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    const startDetection = async () => {
      try {
        // Upload simulation
        setStatus('uploading');
        for (let i = 0; i <= 100; i += 5) {
          if (!mounted) return;
          setProgress(i);
          await new Promise(r => setTimeout(r, 50));
        }
        
        // Processing simulation
        if (!mounted) return;
        setStatus('processing');
        setProgress(0);
        
        // Simulate AI processing
        const result = await simulateDetection(upload.file);
        
        if (!mounted) return;
        setStatus('complete');
        setProgress(100);
        onComplete(result);
        
      } catch (err) {
        if (!mounted) return;
        setStatus('error');
        setError('An error occurred during detection. Please try again.');
      }
    };
    
    startDetection();
    
    return () => {
      mounted = false;
    };
  }, [upload.file, onComplete]);

  // Status-specific UI elements
  const statusIcon = () => {
    switch (status) {
      case 'uploading':
        return null;
      case 'processing':
        return <Clock className="animate-pulse text-blue-500" size={20} />;
      case 'error':
        return <AlertCircle className="text-red-500" size={20} />;
      default:
        return null;
    }
  };

  const statusText = () => {
    switch (status) {
      case 'uploading':
        return 'Uploading content...';
      case 'processing':
        return 'Analyzing for deepfake patterns...';
      case 'error':
        return error || 'Error during detection';
      default:
        return 'Preparing...';
    }
  };

  const progressIndicator = () => {
    if (status === 'processing') {
      return (
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 my-2 overflow-hidden">
          <div className="h-full bg-blue-500 rounded-full animate-pulse"></div>
        </div>
      );
    }
    
    return (
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 my-2 overflow-hidden">
        <div 
          className="h-full bg-blue-500 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    );
  };

  return (
    <div className="w-full border border-gray-200 dark:border-gray-700 rounded-xl p-4 bg-white 
      dark:bg-gray-800 shadow-sm transition-all duration-300">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center space-x-2">
          {statusIcon()}
          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
            {statusText()}
          </h3>
        </div>
        
        <button 
          onClick={onCancel}
          className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
        >
          <X size={18} />
        </button>
      </div>
      
      {progressIndicator()}
      
      {status === 'processing' && (
        <div className="mt-2 text-xs text-gray-500 dark:text-gray-400 flex items-center">
          <span className="animate-pulse mr-1">•</span> 
          Applying AI-powered detection algorithms...
        </div>
      )}
    </div>
  );
};

export default DetectionProgress;