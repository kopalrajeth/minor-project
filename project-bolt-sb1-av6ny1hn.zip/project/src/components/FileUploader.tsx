import React, { useState, useRef, useCallback } from 'react';
import { Upload, UploadCloud, X, AlertTriangle } from 'lucide-react';
import { FileUpload } from '../types';
import { createFilePreview, generateId, formatFileSize } from '../utils/helpers';

interface FileUploaderProps {
  onFileSelect: (file: FileUpload) => void;
}

const FileUploader: React.FC<FileUploaderProps> = ({ onFileSelect }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const validateFile = (file: File): boolean => {
    // Accept images and videos under 50MB
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/quicktime'];
    const maxSize = 50 * 1024 * 1024; // 50MB
    
    if (!validTypes.includes(file.type)) {
      setError('Invalid file type. Please upload an image (JPEG, PNG, GIF) or video (MP4, MOV).');
      return false;
    }
    
    if (file.size > maxSize) {
      setError(`File too large. Maximum size is ${formatFileSize(maxSize)}.`);
      return false;
    }
    
    setError(null);
    return true;
  };

  const processFile = async (file: File) => {
    if (!validateFile(file)) return;
    
    const preview = await createFilePreview(file);
    const newUpload: FileUpload = {
      id: generateId(),
      file,
      preview,
      status: 'idle',
      progress: 0,
      timestamp: Date.now()
    };
    
    onFileSelect(newUpload);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  }, [onFileSelect]);

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
      e.target.value = ''; // Reset input
    }
  };

  const handleButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="w-full">
      <div
        className={`relative border-2 border-dashed rounded-xl p-8 transition-all duration-300 text-center
          ${isDragging 
            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
            : 'border-gray-300 hover:border-gray-400 dark:border-gray-700 dark:hover:border-gray-600'
          } dark:bg-gray-800/30 bg-white
          shadow-sm hover:shadow-md dark:shadow-gray-900/30`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <input
          type="file"
          className="hidden"
          ref={fileInputRef}
          onChange={handleFileInputChange}
          accept="image/jpeg,image/png,image/gif,video/mp4,video/quicktime"
        />
        
        <div className="flex flex-col items-center justify-center py-4">
          <UploadCloud 
            className={`mb-4 ${isDragging ? 'text-blue-500 animate-pulse' : 'text-gray-400 dark:text-gray-500'}`} 
            size={64} 
          />
          <h3 className="text-lg font-medium mb-2 text-gray-800 dark:text-gray-100">
            Upload content for analysis
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6 max-w-md">
            Drag and drop your image or video here, or click to browse
          </p>
          
          <button
            onClick={handleButtonClick}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg 
            transition-colors flex items-center gap-2 shadow-sm"
          >
            <Upload size={16} /> Browse Files
          </button>
          
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-4">
            Accepted formats: JPEG, PNG, GIF, MP4, MOV. Max size: 50MB
          </p>
        </div>
        
        {error && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-red-100 dark:bg-red-900/50 
            border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200 px-4 py-2 rounded-lg 
            flex items-center space-x-2 text-sm animate-fadeIn">
            <AlertTriangle size={16} />
            <span>{error}</span>
            <button 
              onClick={() => setError(null)}
              className="ml-2 text-red-700 dark:text-red-300 hover:text-red-900 dark:hover:text-red-100"
            >
              <X size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FileUploader;